package com.example.rucafe;

/**
 * This class is used for making menuItem
 * @author  Alark Patel, Nicolas Ku
 *
 */
public class MenuItem {

    /**
     * Creates an prices for items such as Donuts and coffee and its ingredients.
     */
    public void itemPrice() {

    }
}